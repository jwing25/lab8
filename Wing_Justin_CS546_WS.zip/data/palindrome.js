function palindromeCheck(text){

    let array = text.split("");
    let reverseArray = array.reverse();
    let reversedString = reverseArray.join("");
if(reversedString === text){
  return true;
}
else{
  return false;
}
}

module.exports = {
  palindromeCheck
};

