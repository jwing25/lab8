
const palindromeData = require('./palindrome');


module.exports = {
  palindrome: palindromeData
};