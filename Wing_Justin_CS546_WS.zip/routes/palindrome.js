const express = require("express");
const router = express.Router();
const data = require("../data")


router.get("/", async (req, res) => {
  try {
  res.render('posts/index', {title: "The Best Palindrome Checker in the World!"});
  } catch (e) {
    res.status(500).json(e);
  }
});

router.post("/result", async (req, res) => {
  
    try{
      let palindromeCheckText= req.body["text-to-test"].toString();

      if(!palindromeCheckText || palindromeCheckText.trim().length < 1){
        res.status(400).render('posts/index', {hasErrors: true});
      }
      else{
      let removeWhiteSpace = palindromeCheckText.replace(/\s/g,'');
      let lowerCaseString = removeWhiteSpace.toLowerCase();
      const regex = /[!.?-]/g;
      let removedPunctuation = lowerCaseString.replace(regex, "");
      removedPunctuation = removedPunctuation.replace("’", "");
      removedPunctuation = removedPunctuation.replace(",", "");
      removedPunctuation = removedPunctuation.replace("\'", "");
      removedPunctuation = removedPunctuation.replace("\"", "");

     if(!removedPunctuation.match(/^[a-z0-9]+$/i)){
        res.status(400).render('posts/index', {hasErrors: true});
    }

      else{
        const isPalindrome = data.palindrome.palindromeCheck(removedPunctuation);
        res.render('posts/result', {title: "The Palindrome Results!", isPalindrome: isPalindrome, palindromeCheckText: palindromeCheckText});
      }
    }
  }
     catch(e){
      res.status(500).json(e);
    }
  });





module.exports = router;